create unique index PRIMARY_KEY_83
    on MOVIES_ACTORS (MOVIE_ID, ACTOR_ID);

