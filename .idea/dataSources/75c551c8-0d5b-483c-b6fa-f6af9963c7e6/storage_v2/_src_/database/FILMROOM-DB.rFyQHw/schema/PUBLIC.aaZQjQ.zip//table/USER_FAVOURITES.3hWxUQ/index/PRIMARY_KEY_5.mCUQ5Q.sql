create unique index PRIMARY_KEY_5
    on USER_FAVOURITES (USER_ID, MOVIE_ID);

